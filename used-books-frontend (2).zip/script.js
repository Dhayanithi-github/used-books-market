
const form = document.getElementById('book-form');
const bookList = document.getElementById('book-list');
const themeToggle = document.getElementById('theme-toggle');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const book = {
    title: form.title.value,
    author: form.author.value,
    price: form.price.value,
    condition: form.condition.value,
    seller: form.seller.value,
    contact: form.contact.value
  };

  await fetch('http://localhost:3000/books', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(book)
  });

  form.reset();
  loadBooks();
});

async function loadBooks() {
  const res = await fetch('http://localhost:3000/books');
  const books = await res.json();

  bookList.innerHTML = '';
  books.forEach(book => {
    const div = document.createElement('div');
    div.classList.add('book-card');
    div.innerHTML = `
      <h3>${book.title}</h3>
      <p><strong>Author:</strong> ${book.author}</p>
      <p><strong>Price:</strong> ₹${book.price}</p>
      <p><strong>Condition:</strong> ${book.condition}</p>
      <p><strong>Seller:</strong> ${book.seller}</p>
      <p><strong>Contact:</strong> ${book.contact}</p>
    `;
    bookList.appendChild(div);
  });
}

themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  themeToggle.textContent =
    document.body.classList.contains('dark') ? '☀️ Light Mode' : '🌙 Dark Mode';
});

loadBooks();
