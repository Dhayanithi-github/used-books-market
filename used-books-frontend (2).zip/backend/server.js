
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const DATA_FILE = './books.json';

// Helper function to read data
function readData() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, '[]');
  }
  const data = fs.readFileSync(DATA_FILE);
  return JSON.parse(data);
}

// Helper function to write data
function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// Get all books
app.get('/books', (req, res) => {
  const books = readData();
  res.json(books);
});

// Post a new book
app.post('/books', (req, res) => {
  const books = readData();
  books.push(req.body);
  writeData(books);
  res.status(201).json({ message: 'Book added!' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
